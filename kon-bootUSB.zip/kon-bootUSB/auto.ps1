#
#
# KON-BOOT POWERSHELL AUTOSCRIPT
# (you can edit it freely, please note it will only work for commercial license holders)
# 
# http://thelead82.com - @thelead82.com
#
#

Write-Host "# hello from powershell script (editable file 'auto.ps1') "
Write-Host "# whoami: " -NoNewline;
$who = whoami
Write-Host $who "" -ForegroundColor white
